import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
export default async function Account(){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/login");
 const {data:profile}=await supabase.from("profiles").select("full_name,phone,role,is_suspended,created_at").eq("id",user.id).maybeSingle();
 return <main dir="rtl" style={{maxWidth:800,margin:"40px auto",padding:24,fontFamily:"Arial"}}>
 <Link href="/">← ہوم</Link><h1 style={{color:"#155e45"}}>میرا اکاؤنٹ</h1><section style={{border:"1px solid #ddd",padding:20,borderRadius:12}}>
 <h2>{profile?.full_name||user.user_metadata?.full_name||"صارف"}</h2><p>ای میل: {user.email}</p><p>موبائل: {profile?.phone||user.user_metadata?.phone||"درج نہیں"}</p><p>اکاؤنٹ: {user.email_confirmed_at?"تصدیق شدہ":"ای میل تصدیق زیرِ انتظار"}</p><p>حیثیت: {profile?.is_suspended?"معطل":"فعال"}</p>
 <p style={{color:"#666"}}>یہ اکاؤنٹ ڈیش بورڈ ابتدائی مرحلہ ہے؛ اشتہار لگانے اور اپنی پوسٹس کا انتظام اگلے مرحلے میں شامل ہوگا۔</p></section><form action="/auth/logout" method="post" style={{marginTop:20}}><button style={{padding:12,borderRadius:8}}>لاگ آؤٹ</button></form></main>
}
