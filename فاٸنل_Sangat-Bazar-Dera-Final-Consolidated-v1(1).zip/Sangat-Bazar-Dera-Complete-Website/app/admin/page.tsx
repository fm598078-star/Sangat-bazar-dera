import Link from 'next/link';
import { requireAdmin } from '@/lib/supabase/admin-guard';

const areas = [
  ['Pending advertisements','/admin/ads?status=pending'],
  ['Published / expired ads','/admin/ads'],
  ['Users & suspension','/admin/users'],
  ['Service profiles','/admin/services'],
  ['Categories','/admin/categories'],
  ['Payments','/admin/payments'],
  ['Complaints & appeals','/admin/reports'],
  ['Announcements & polls','/admin/community'],
  ['Company advertisements','/admin/company-ads'],
  ['Audit log','/admin/audit'],
  ['Site settings','/admin/settings'],
];

export default async function AdminHome() {
  await requireAdmin();
  return <main className="mx-auto max-w-5xl p-6" dir="rtl">
    <h1 className="mb-2 text-3xl font-bold">انتظامی پینل — بنیاد</h1>
    <p className="mb-6 text-sm text-amber-700">یہ ابتدائی نیویگیشن ہے؛ ہر ماڈیول کے محفوظ API اور مکمل UI اگلے مراحل میں بنیں گے۔</p>
    <div className="grid gap-3 sm:grid-cols-2">
      {areas.map(([label,href])=><Link key={href} href={href} className="rounded-xl border p-4 hover:bg-gray-50">{label} ←</Link>)}
    </div>
  </main>;
}
