import type {Metadata} from 'next';
export const metadata:Metadata={title:'Sangat Bazar Dera',description:'ڈیرہ اسماعیل خان کی مقامی مارکیٹ'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="ur" dir="rtl"><body style={{margin:0,fontFamily:'Arial,sans-serif'}}>{children}</body></html>}
