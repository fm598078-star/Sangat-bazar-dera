# سنگت بازار ڈیرہ — ایک مرکزی پروجیکٹ ZIP

## آپ کے لیے اہم
یہ تمام دستیاب Starter/Phase 2/Phase 3/Phase 4 فائلوں کا **ایک مرکزی Next.js پروجیکٹ** ہے۔ الگ الگ Phase ZIP استعمال نہ کریں۔

## اس ZIP میں ابھی کیا کام موجود ہے؟
- Next.js 14 + TypeScript بنیاد
- Supabase database schema (categories, profiles, ads/service/payment foundations وغیرہ)
- Signup, email verification callback, login/logout, forgot/reset password
- محفوظ account page اور Admin route guard کی بنیاد
- Admin/security SQL اور 48-hour expiry کا SQL/cleanup documentation
- Urdu setup/deployment documentation

## کیا ابھی مکمل نہیں؟ (صاف وضاحت)
یہ موجودہ فائلیں **production-ready مکمل marketplace نہیں** ہیں۔ اشتہار پوسٹ کرنے کا UI/API، تصاویر upload کا مکمل workflow، Admin approval/rejection کی مکمل screens/actions، محفوظ counter/cleanup scheduler، payment verification اور end-to-end tests ابھی مکمل implement نہیں۔ اس ZIP کو deploy کر کے public business شروع نہ کریں جب تک یہ باقی modules مکمل اور test نہ ہوں۔

## شروع کرنے کا درست طریقہ
1. پہلے Supabase project بنائیں۔
2. SQL Editor میں `supabase/SETUP-ALL.sql` ایک مرتبہ چلائیں (نئے خالی project پر)۔
3. Authentication > URL Configuration میں localhost اور بعد میں Netlify callback URLs درج کریں۔
4. Netlify پر GitHub repository import کریں؛ Next.js runtime خود configure ہونے دیں۔
5. Netlify Environment variables میں `NEXT_PUBLIC_SUPABASE_URL` اور `NEXT_PUBLIC_SUPABASE_ANON_KEY` لگائیں۔
6. Deploy اور test کریں؛ deployment کی تفصیلی اردو guide `docs/DEPLOY-URDU.md` میں ہے۔

## ضروری احتیاط
- `.env.example` کو `.env.local` بنائیں اور اپنی Supabase values ڈالیں۔
- Supabase `service_role` key کبھی browser یا `NEXT_PUBLIC_` میں نہ ڈالیں۔
- Admin صرف مالک SQL کے ذریعے بنائے؛ signup سے admin نہیں بن سکتا۔
- `SETUP-ALL.sql` موجودہ database پر بغیر backup/سمجھے دوبارہ نہ چلائیں۔
