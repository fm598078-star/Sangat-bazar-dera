# Phase 4 — رجسٹریشن، لاگ اِن اور اکاؤنٹ

## ZIP میں کیا شامل ہے؟
- `/signup`: نام، فون (اختیاری)، ای میل، پاس ورڈ کے ساتھ رجسٹریشن
- `/login`: ای میل/پاس ورڈ لاگ اِن
- `/forgot-password`: Reset link بھیجنا
- `/reset-password`: نیا پاس ورڈ
- `/auth/callback`: Supabase email confirmation اور recovery callback
- `/account`: محفوظ server-side صارف اکاؤنٹ صفحہ
- `/auth/logout`: session ختم کرنے کا route
- `supabase/phase4-auth.sql`: profile trigger، role/suspension columns اور RLS policies
- Phase 2 starter اور Phase 3 security/admin/expiry files برقرار رکھی گئی ہیں۔

## سیٹ اپ (ضروری)
1. Supabase Dashboard > SQL Editor میں `supabase/phase4-auth.sql` چلائیں (Phase 2 schema پہلے موجود ہو)۔\n2. اس کے بعد `supabase/phase3-security.sql` چلائیں؛ Phase 3 admin function کے لیے role column اب موجود ہوگا۔
3. Supabase Authentication > Providers > Email فعال کریں؛ Email confirmations ON رکھیں۔
4. Authentication > URL Configuration میں Site URL اور Redirect URLs شامل کریں:
   - `http://localhost:3000/auth/callback`
   - اپنی Netlify domain کا `/auth/callback`
5. `.env.example` کو `.env.local` بنائیں اور URL/anon key درج کریں۔
6. `npm install` پھر `npm run dev`۔
7. `/signup` سے اکاؤنٹ بنائیں؛ inbox میں verification link کھولیں؛ پھر `/login`۔
7. کامیاب login کے بعد `/account` کھلے گا۔

## اہم حفاظت
- Admin role کسی signup form سے نہیں دیا جاتا؛ صرف trusted owner SQL سے مقرر کرے۔
- Service role key browser یا `NEXT_PUBLIC_` variables میں کبھی نہ رکھیں۔
- Phase 3 SQL کو اپنے Phase 2 schema کے مطابق staging میں validate کریں؛ Phase 3 expiry خود scheduled deletion نہیں چلاتا۔
- یہ Phase 4 development increment ہے، مکمل production marketplace نہیں۔ ابھی ad submission، image upload، moderation اور scheduled cleanup شامل نہیں۔

## Admin بنانا
Authentication > Users سے UUID لیں، پھر trusted SQL:
`update public.profiles set role='admin' where id='YOUR-UUID';`

Phase 2 کے `private.is_admin()` اور پرانی `user_roles` پالیسیوں کے ساتھ مطابقت کے لیے Phase 4 SQL اب `private.is_admin()` کو profile role سے جوڑتا ہے؛ signup پر user_roles میں user row بھی بنتی ہے۔
