# Netlify + Supabase Deployment — اردو

## حصہ A: Supabase (پہلے)
1. https://supabase.com/dashboard کھولیں اور New project بنائیں۔ Project password محفوظ رکھیں۔
2. Project کے SQL Editor > New query میں جائیں۔
3. ZIP کے `supabase/SETUP-ALL.sql` کو مکمل copy/paste کر کے Run کریں۔ صرف نئے خالی project پر ایک مرتبہ۔
4. Project Settings > API (یا API Keys) سے Project URL اور anon/public key copy کریں۔ service_role/secret key استعمال نہ کریں۔
5. Authentication > Providers میں Email فعال اور Confirm email ON رکھیں۔
6. Authentication > URL Configuration میں Site URL عارضی طور پر `http://localhost:3000` رکھیں اور Redirect URLs میں `http://localhost:3000/auth/callback` شامل کریں۔ Netlify deploy کے بعد اپنی `https://YOUR-SITE.netlify.app/auth/callback` بھی شامل کریں۔

## حصہ B: GitHub پر project
1. ZIP extract کریں۔ اندر `Sangat-Bazar-Dera-Complete-Website` project folder ہوگا۔
2. GitHub پر نئی repository بنائیں۔ project کے اندر کی فائلیں (package.json, app, lib, supabase وغیرہ) repository root پر upload/push کریں؛ outer folder کے اندر دوبارہ nested folder نہ رکھیں۔

## حصہ C: Netlify
1. https://app.netlify.com/ کھولیں > Add new site > Import an existing project > GitHub منتخب کریں۔
2. اپنی repository منتخب کریں۔ Next.js کے لیے Netlify کی detected Next.js build/runtime settings استعمال کریں؛ اسے static export نہ بنائیں۔
3. Site configuration > Environment variables میں یہ دو variables شامل کریں:
   - `NEXT_PUBLIC_SUPABASE_URL` = Supabase Project URL
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = Supabase anon/public key
4. Deploy site دبائیں۔ Deploy log میں build کامیاب ہونا چاہیے۔
5. Site URL کھول کر signup/login/forgot-password flows آزمائیں۔

## Admin بنانا
1. پہلے website سے اپنا user register کریں اور email verify کریں۔
2. Supabase Authentication > Users سے اپنی user UUID copy کریں۔
3. SQL Editor میں یہ چلائیں (UUID بدل کر):
   `update public.profiles set role='admin' where id='YOUR-UUID';`
4. Admin route `/admin` کھول کر چیک کریں۔

## اہم
اس ورژن میں marketplace کے کچھ modules ابھی مکمل نہیں؛ Deploy صرف development/staging verification کے لیے کریں، public launch نہیں۔ service_role key کو Netlify client env میں ہرگز نہ رکھیں۔
