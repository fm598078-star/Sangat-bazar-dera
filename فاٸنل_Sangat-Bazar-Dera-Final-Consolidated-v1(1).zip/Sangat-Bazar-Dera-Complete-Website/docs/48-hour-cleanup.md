# 48-hour deletion workflow (critical requirement)

## Required behavior
- Timer starts only when an admin approves/publishes an ad.
- `expires_at = approved_at + 48 hours` (UTC).
- At expiry, delete ad images from Supabase Storage and delete the ad's detail row/related image rows.
- Keep the lifetime published count. Increment exactly once per ad at first publication; do not increment on reapproval; never decrement on expiry.
- Worker retries failures and records an admin-visible error/audit event.

## Safe implementation pattern
1. Keep the Storage bucket private (`ad-images`).
2. A server-side scheduled function (Supabase Edge Function + pg_cron/HTTP invocation, or Netlify Scheduled Function) queries due IDs using a service-role key held only in server secrets.
3. For each ad, fetch all `storage_path` values, delete files via Supabase Storage API, then delete related rows and ad row in a transaction/RPC where possible.
4. Mark the task complete only after successful Storage deletion and DB cleanup. Retry with exponential backoff; log failures.
5. Use an idempotency key/ad ID and a separate cleanup log table; never double-increment publication totals.
6. Monitor job runs and alert admin on failures.

**Not included:** live scheduled execution. Configure the schedule in Phase 6 and test with a staging ad. Never put `SUPABASE_SERVICE_ROLE_KEY` in browser code or `NEXT_PUBLIC_*`.
