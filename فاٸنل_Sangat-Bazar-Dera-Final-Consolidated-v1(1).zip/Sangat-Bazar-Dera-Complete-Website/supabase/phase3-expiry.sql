-- 48-hour approved advertisement expiration.
-- Adapt column names if Phase 2 schema differs. This SQL assumes:
-- ads(id, status, approved_at, expires_at, deleted_at)
-- ad_images(id, ad_id, storage_path)
-- published_ads_counter(singleton_id, total_published)
-- Use Supabase Storage deletion API from a server/Edge Function; SQL cannot safely
-- delete Storage files by itself.

alter table public.ads add column if not exists approved_at timestamptz;
alter table public.ads add column if not exists expires_at timestamptz;
alter table public.ads add column if not exists expired_at timestamptz;

create or replace function public.set_ad_48h_expiry()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.status = 'approved' and (old.status is distinct from 'approved') then
    if new.approved_at is null then new.approved_at := now(); end if;
    new.expires_at := new.approved_at + interval '48 hours';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_ad_48h_expiry on public.ads;
create trigger trg_ad_48h_expiry
before update of status on public.ads
for each row execute function public.set_ad_48h_expiry();

-- Idempotent expiry marker. The actual data + Storage removal is performed by
-- the secure scheduled worker (docs/48-hour-cleanup.md).
create index if not exists ads_due_expiry_idx
on public.ads (expires_at) where status='approved' and expired_at is null;
