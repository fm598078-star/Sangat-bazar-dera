-- Sangat Bazar Dera: Full DB audit report (read-only; run after SETUP-ALL.sql)
-- Returns one row per audit section; copy/export all results.
with
expected_tables(tbl) as (values
 ('profiles'),('user_roles'),('categories'),('ads'),('ad_images'),('permanent_ad_counter'),('service_profiles'),('payments'),('site_settings'),('announcements'),('polls'),('poll_votes'),('feedback'),('complaints'),('appeals'),('company_ad_applications'),('company_advertisements'),('social_publishing_logs'),('admin_audit_logs')
),
sections as (
 select '01_TABLES' section, jsonb_agg(jsonb_build_object('table',e.tbl,'exists',to_regclass('public.'||e.tbl) is not null) order by e.tbl) report from expected_tables e
 union all
 select '02_COLUMNS', coalesce(jsonb_agg(jsonb_build_object('table',c.table_name,'column',c.column_name,'type',c.data_type,'nullable',c.is_nullable,'default',c.column_default) order by c.table_name,c.ordinal_position),'[]'::jsonb) from information_schema.columns c where c.table_schema='public' and c.table_name in (select tbl from expected_tables)
 union all
 select '03_PRIMARY_FOREIGN_UNIQUE_CHECKS', coalesce(jsonb_agg(jsonb_build_object('table',tc.table_name,'constraint',tc.constraint_name,'type',tc.constraint_type,'definition',pg_get_constraintdef(k.oid)) order by tc.table_name,tc.constraint_name),'[]'::jsonb) from information_schema.table_constraints tc join pg_constraint k on k.conname=tc.constraint_name join pg_namespace n on n.oid=k.connamespace and n.nspname='public' where tc.table_schema='public' and tc.table_name in (select tbl from expected_tables) and tc.constraint_type in ('PRIMARY KEY','FOREIGN KEY','UNIQUE','CHECK')
 union all
 select '04_RLS', coalesce(jsonb_agg(jsonb_build_object('table',e.tbl,'rls_enabled',coalesce(c.relrowsecurity,false),'force_rls',coalesce(c.relforcerowsecurity,false)) order by e.tbl),'[]'::jsonb) from expected_tables e left join pg_class c on c.oid=to_regclass('public.'||e.tbl)
 union all
 select '05_POLICIES', coalesce(jsonb_agg(jsonb_build_object('table',p.tablename,'policy',p.policyname,'command',p.cmd,'roles',p.roles,'using',p.qual,'check',p.with_check) order by p.tablename,p.policyname),'[]'::jsonb) from pg_policies p where p.schemaname='public' and p.tablename in (select tbl from expected_tables)
 union all
 select '06_FUNCTIONS', coalesce(jsonb_agg(jsonb_build_object('schema',n.nspname,'function',p.proname,'args',pg_get_function_identity_arguments(p.oid),'security_definer',p.prosecdef,'search_path',p.proconfig) order by n.nspname,p.proname),'[]'::jsonb) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname in ('public','private') and p.proname in ('is_admin','handle_new_user','set_ad_48h_expiry')
 union all
 select '07_TRIGGERS', coalesce(jsonb_agg(jsonb_build_object('table',c.relname,'trigger',t.tgname,'enabled',t.tgenabled,'definition',pg_get_triggerdef(t.oid)) order by c.relname,t.tgname),'[]'::jsonb) from pg_trigger t join pg_class c on c.oid=t.tgrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and not t.tgisinternal
 union all
 select '08_INDEXES', coalesce(jsonb_agg(jsonb_build_object('table',c.relname,'index',i.relname,'definition',pg_get_indexdef(i.oid)) order by c.relname,i.relname),'[]'::jsonb) from pg_index x join pg_class c on c.oid=x.indrelid join pg_class i on i.oid=x.indexrelid join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relname in (select tbl from expected_tables)
 union all
 select '09_STORAGE_BUCKETS', coalesce(jsonb_agg(jsonb_build_object('bucket',id,'public',public,'file_size_limit',file_size_limit,'allowed_mime_types',allowed_mime_types) order by id),'[]'::jsonb) from storage.buckets
 union all
 select '10_STORAGE_POLICIES', coalesce(jsonb_agg(jsonb_build_object('policy',policyname,'command',cmd,'roles',roles,'using',qual,'check',with_check) order by policyname),'[]'::jsonb) from pg_policies where schemaname='storage' and tablename='objects'
)
select section, report from sections order by section;
