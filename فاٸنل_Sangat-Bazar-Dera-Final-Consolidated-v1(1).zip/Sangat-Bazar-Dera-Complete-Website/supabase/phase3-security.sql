-- Phase 3 security hardening. Run only after Phase 2 schema exists.
-- IMPORTANT: Review against your actual schema and test in a staging project.

-- Admin authorization is database-backed (never trust a client-supplied role).
create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and coalesce(p.is_suspended,false)=false
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Admin-only audit log writes should be performed through trusted server routes.
alter table public.admin_audit_logs enable row level security;
drop policy if exists audit_admin_read on public.admin_audit_logs;
create policy audit_admin_read on public.admin_audit_logs
for select to authenticated using (public.is_admin());

-- Storage bucket setup (create bucket 'ad-images' in Supabase Storage, private).
-- These policies allow owners to upload into their own UUID folder.
-- Public image access should be via approved-ad server/public signed URLs or a public bucket
-- only after moderation; private bucket is safer as a default.
drop policy if exists "ad_images_owner_insert" on storage.objects;
create policy "ad_images_owner_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'ad-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "ad_images_owner_delete" on storage.objects;
create policy "ad_images_owner_delete" on storage.objects
for delete to authenticated
using (
  bucket_id = 'ad-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "ad_images_owner_update" on storage.objects;
create policy "ad_images_owner_update" on storage.objects
for update to authenticated
using (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text)
with check (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text);

-- Do not expose storage objects indiscriminately. Public reads must be mediated by
-- approved-ad checks / signed URLs in a server route.
