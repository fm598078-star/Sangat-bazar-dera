-- Phase 4 Auth/profile setup. Apply after Phase 2 schema; then run Phase 3 security SQL.
begin;
alter table public.profiles add column if not exists role text not null default 'user';
alter table public.profiles add column if not exists is_suspended boolean not null default false;
alter table public.profiles add column if not exists updated_at timestamptz not null default now();
do $$ begin
 if not exists(select 1 from pg_constraint where conname='profiles_role_check') then
  alter table public.profiles add constraint profiles_role_check check(role in ('user','admin'));
 end if;
end $$;
-- Phase 2 RLS policies call private.is_admin(); align it with the Phase 3 profile role.
create or replace function private.is_admin()
returns boolean language sql stable security definer set search_path=''
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and not p.is_suspended) $$;
revoke all on function private.is_admin() from public;
grant execute on function private.is_admin() to authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,full_name,phone,role,is_suspended)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name','نیا صارف'),new.raw_user_meta_data->>'phone','user',false)
 on conflict(id) do nothing;
 insert into public.user_roles(user_id,role) values(new.id,'user') on conflict(user_id) do nothing;
 return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security;
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated using(id=auth.uid());
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='user');
grant select,update on public.profiles to authenticated;
commit;
-- Existing accounts: create missing profile rows (names can be edited later).
insert into public.profiles(id,full_name,role,is_suspended)
select u.id,coalesce(u.raw_user_meta_data->>'full_name','صارف'), 'user', false
from auth.users u left join public.profiles p on p.id=u.id where p.id is null
on conflict(id) do nothing;


-- Keep legacy Phase 2 role records for existing users.
insert into public.user_roles(user_id,role) select id,'user' from auth.users on conflict(user_id) do nothing;
