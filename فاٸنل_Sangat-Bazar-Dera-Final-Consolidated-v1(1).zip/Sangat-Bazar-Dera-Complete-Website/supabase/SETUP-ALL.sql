-- Unified SQL for a NEW Supabase project. Apply in order.


-- ===== schema.sql =====
-- Sangat Bazar Dera v0.2 database foundation
-- Run as one script in Supabase SQL Editor. Admin role is assigned manually by trusted project owner.
create extension if not exists pgcrypto;
create schema if not exists private;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null,
 phone text,
 is_suspended boolean not null default false,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.user_roles(
 user_id uuid primary key references auth.users(id) on delete cascade,
 role text not null default 'user' check(role in ('user','admin')),
 assigned_at timestamptz not null default now()
);
create or replace function private.is_admin()
returns boolean language sql stable security definer set search_path=''
as $$ select exists(select 1 from public.user_roles r where r.user_id=auth.uid() and r.role='admin') $$;
revoke all on function private.is_admin() from public;
grant execute on function private.is_admin() to authenticated;

create table if not exists public.categories(
 id uuid primary key default gen_random_uuid(), name_ur text not null,name_en text not null,
 slug text unique not null,parent_id uuid references public.categories(id) on delete set null,
 is_active boolean not null default true,sort_order int not null default 0,created_at timestamptz default now()
);
insert into public.categories(name_ur,name_en,slug,sort_order) values
('خرید و فروخت','Buy & Sell','buy-sell',1),('کرایہ','Rent','rent',2),('ہیلتھ','Health','health',3),
('پکوان','Cooking','cooking',4),('پک اَپ اینڈ ڈراپ','Pickup & Drop','pickup-drop',5),('شاپس','Shops','shops',6)
on conflict(slug) do nothing;

create table if not exists public.ads(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),
 category_id uuid not null references public.categories(id),title text not null,description text not null,
 price numeric(14,2),phone text not null,location text not null,
 status text not null default 'pending' check(status in ('pending','approved','rejected','expired')),
 approved_at timestamptz,expires_at timestamptz,counted_at timestamptz,
 created_at timestamptz not null default now(),rejected_reason text
);
create index if not exists ads_status_expiry_idx on public.ads(status,expires_at);
create index if not exists ads_owner_idx on public.ads(owner_id);
create table if not exists public.ad_images(
 id uuid primary key default gen_random_uuid(),ad_id uuid not null references public.ads(id) on delete cascade,
 storage_path text not null,created_at timestamptz not null default now()
);
create table if not exists public.permanent_ad_counter(
 singleton boolean primary key default true check(singleton),total_approved bigint not null default 0
);
insert into public.permanent_ad_counter(singleton,total_approved) values(true,0) on conflict(singleton) do nothing;

create table if not exists public.service_profiles(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),
 kind text not null check(kind in ('health','cooking','transport','shop')),name text not null,
 description text not null,phone text not null,location text not null,image_paths text[] not null default '{}',
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.payments(
 id uuid primary key default gen_random_uuid(),owner_id uuid not null references auth.users(id),
 ad_id uuid references public.ads(id),amount numeric(12,2) not null check(amount>=0),
 jazzcash_reference text,receipt_path text,status text not null default 'pending' check(status in ('pending','verified','rejected')),
 created_at timestamptz default now(),verified_by uuid,verified_at timestamptz
);
create table if not exists public.site_settings(key text primary key,value jsonb not null default '{}');
create table if not exists public.announcements(id uuid primary key default gen_random_uuid(),title text not null,body text not null,published boolean default false,created_at timestamptz default now());
create table if not exists public.polls(id uuid primary key default gen_random_uuid(),question text not null,options jsonb not null,active boolean default true,created_at timestamptz default now());
create table if not exists public.poll_votes(id uuid primary key default gen_random_uuid(),poll_id uuid not null references public.polls(id) on delete cascade,user_id uuid not null references auth.users(id),option_index int not null,created_at timestamptz default now(),unique(poll_id,user_id));
create table if not exists public.feedback(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id),rating text not null check(rating in ('good','very_good','not_at_all')),created_at timestamptz default now());
create table if not exists public.complaints(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id),target_type text,target_id uuid,message text not null,status text not null default 'open',created_at timestamptz default now());
create table if not exists public.appeals(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id),ad_id uuid references public.ads(id),message text not null,status text not null default 'pending',created_at timestamptz default now());
create table if not exists public.company_ad_applications(id uuid primary key default gen_random_uuid(),user_id uuid references auth.users(id),company_name text not null,contact text not null,details text not null,status text not null default 'pending',created_at timestamptz default now());
create table if not exists public.company_advertisements(id uuid primary key default gen_random_uuid(),title text not null,media_url text,target_url text,starts_at timestamptz,ends_at timestamptz,active boolean default false);
create table if not exists public.social_publishing_logs(id uuid primary key default gen_random_uuid(),platform text not null,post_text text,status text,response jsonb,created_at timestamptz default now());
create table if not exists public.admin_audit_logs(id bigint generated always as identity primary key,admin_id uuid,action text not null,entity_type text,entity_id text,details jsonb,created_at timestamptz default now());

-- RLS enable all tables
do $$ declare t text; begin foreach t in array array['profiles','user_roles','categories','ads','ad_images','permanent_ad_counter','service_profiles','payments','site_settings','announcements','polls','poll_votes','feedback','complaints','appeals','company_ad_applications','company_advertisements','social_publishing_logs','admin_audit_logs'] loop execute format('alter table public.%I enable row level security',t); end loop; end $$;
-- policies (drop first for rerun-safe deployment)
drop policy if exists profiles_self_select on public.profiles;
create policy profiles_self_select on public.profiles for select to authenticated using(id=auth.uid() or private.is_admin());
drop policy if exists profiles_self_update on public.profiles;
create policy profiles_self_update on public.profiles for update to authenticated using(id=auth.uid() and not private.is_admin()) with check(id=auth.uid());
drop policy if exists categories_public_select on public.categories;
create policy categories_public_select on public.categories for select using(is_active or private.is_admin());
drop policy if exists roles_self_select on public.user_roles;
create policy roles_self_select on public.user_roles for select to authenticated using(user_id=auth.uid() or private.is_admin());
drop policy if exists ads_public_approved on public.ads;
create policy ads_public_approved on public.ads for select using((status='approved' and expires_at>now()) or owner_id=auth.uid() or private.is_admin());
drop policy if exists ads_insert_owner_pending on public.ads;
create policy ads_insert_owner_pending on public.ads for insert to authenticated with check(owner_id=auth.uid() and status='pending' and approved_at is null and expires_at is null and counted_at is null);
drop policy if exists ads_admin_update on public.ads;
create policy ads_admin_update on public.ads for update to authenticated using(private.is_admin()) with check(private.is_admin());
drop policy if exists ads_owner_delete_pending on public.ads;
create policy ads_owner_delete_pending on public.ads for delete to authenticated using(owner_id=auth.uid() and status='pending');
drop policy if exists ad_images_read_policy on public.ad_images;
create policy ad_images_read_policy on public.ad_images for select using (exists (select 1 from public.ads a where a.id=ad_id and ((a.status='approved' and a.expires_at>now()) or a.owner_id=auth.uid() or private.is_admin())));
drop policy if exists ad_images_insert_policy on public.ad_images;
create policy ad_images_insert_policy on public.ad_images for insert to authenticated with check(exists(select 1 from public.ads a where a.id=ad_id and a.owner_id=auth.uid() and a.status='pending'));
drop policy if exists services_read_policy on public.service_profiles;
create policy services_read_policy on public.service_profiles for select using(status='approved' or owner_id=auth.uid() or private.is_admin());
drop policy if exists services_insert_policy on public.service_profiles;
create policy services_insert_policy on public.service_profiles for insert to authenticated with check(owner_id=auth.uid() and status='pending');
drop policy if exists services_owner_update on public.service_profiles;
create policy services_owner_update on public.service_profiles for update to authenticated using(owner_id=auth.uid()) with check(owner_id=auth.uid());
drop policy if exists services_admin_update on public.service_profiles;
create policy services_admin_update on public.service_profiles for update to authenticated using(private.is_admin()) with check(private.is_admin());
drop policy if exists payments_owner_select on public.payments;
create policy payments_owner_select on public.payments for select to authenticated using(owner_id=auth.uid() or private.is_admin());
drop policy if exists payments_owner_insert on public.payments;
create policy payments_owner_insert on public.payments for insert to authenticated with check(owner_id=auth.uid() and status='pending');
drop policy if exists announcements_public_read on public.announcements;
create policy announcements_public_read on public.announcements for select using(published or private.is_admin());
drop policy if exists polls_public_read on public.polls;
create policy polls_public_read on public.polls for select using(active or private.is_admin());
drop policy if exists votes_insert_self on public.poll_votes;
create policy votes_insert_self on public.poll_votes for insert to authenticated with check(user_id=auth.uid());
drop policy if exists votes_read_self_admin on public.poll_votes;
create policy votes_read_self_admin on public.poll_votes for select to authenticated using(user_id=auth.uid() or private.is_admin());
drop policy if exists feedback_insert_self on public.feedback;
create policy feedback_insert_self on public.feedback for insert to authenticated with check(user_id=auth.uid());
drop policy if exists complaints_insert_self on public.complaints;
create policy complaints_insert_self on public.complaints for insert to authenticated with check(user_id=auth.uid());
drop policy if exists complaints_read_self_admin on public.complaints;
create policy complaints_read_self_admin on public.complaints for select to authenticated using(user_id=auth.uid() or private.is_admin());
drop policy if exists appeals_insert_self on public.appeals;
create policy appeals_insert_self on public.appeals for insert to authenticated with check(user_id=auth.uid());
drop policy if exists appeals_read_self_admin on public.appeals;
create policy appeals_read_self_admin on public.appeals for select to authenticated using(user_id=auth.uid() or private.is_admin());
drop policy if exists company_app_insert_self on public.company_ad_applications;
create policy company_app_insert_self on public.company_ad_applications for insert to authenticated with check(user_id=auth.uid());
drop policy if exists company_app_read_self_admin on public.company_ad_applications;
create policy company_app_read_self_admin on public.company_ad_applications for select to authenticated using(user_id=auth.uid() or private.is_admin());
drop policy if exists company_ads_public_read on public.company_advertisements;
create policy company_ads_public_read on public.company_advertisements for select using(active and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>now()) or private.is_admin());
-- Admin write policies intentionally restricted to authenticated role verified by private.is_admin.
do $$ declare t text; begin foreach t in array array['categories','announcements','polls','site_settings','company_advertisements','social_publishing_logs','admin_audit_logs','permanent_ad_counter','user_roles'] loop
 execute format('drop policy if exists admin_all_%I on public.%I',t,t);
 execute format('create policy admin_all_%I on public.%I for all to authenticated using(private.is_admin()) with check(private.is_admin())',t,t);
end loop; end $$;

-- Signup profile creation trigger
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')); insert into public.user_roles(user_id,role) values(new.id,'user'); return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- IMPORTANT: Admin assignment is performed manually by project owner in SQL Editor:
-- insert into public.user_roles(user_id,role) values('AUTH_USER_UUID','admin') on conflict(user_id) do update set role='admin';
-- The admin's UUID is obtained from Authentication > Users after registering.
-- Ad approval/counter and 48h cleanup are scheduled server-side in later secure phase.


-- ===== phase4-auth.sql =====
-- Phase 4 Auth/profile setup. Apply after Phase 2 schema; then run Phase 3 security SQL.
begin;
alter table public.profiles add column if not exists role text not null default 'user';
alter table public.profiles add column if not exists is_suspended boolean not null default false;
alter table public.profiles add column if not exists updated_at timestamptz not null default now();
do $$ begin
 if not exists(select 1 from pg_constraint where conname='profiles_role_check') then
  alter table public.profiles add constraint profiles_role_check check(role in ('user','admin'));
 end if;
end $$;
-- Phase 2 RLS policies call private.is_admin(); align it with the Phase 3 profile role.
create or replace function private.is_admin()
returns boolean language sql stable security definer set search_path=''
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and not p.is_suspended) $$;
revoke all on function private.is_admin() from public;
grant execute on function private.is_admin() to authenticated;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,full_name,phone,role,is_suspended)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name','نیا صارف'),new.raw_user_meta_data->>'phone','user',false)
 on conflict(id) do nothing;
 insert into public.user_roles(user_id,role) values(new.id,'user') on conflict(user_id) do nothing;
 return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security;
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated using(id=auth.uid());
drop policy if exists profiles_update_own on public.profiles;
create policy profiles_update_own on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='user');
grant select,update on public.profiles to authenticated;
commit;
-- Existing accounts: create missing profile rows (names can be edited later).
insert into public.profiles(id,full_name,role,is_suspended)
select u.id,coalesce(u.raw_user_meta_data->>'full_name','صارف'), 'user', false
from auth.users u left join public.profiles p on p.id=u.id where p.id is null
on conflict(id) do nothing;


-- Keep legacy Phase 2 role records for existing users.
insert into public.user_roles(user_id,role) select id,'user' from auth.users on conflict(user_id) do nothing;


-- ===== phase3-security.sql =====
-- Phase 3 security hardening. Run only after Phase 2 schema exists.
-- IMPORTANT: Review against your actual schema and test in a staging project.

-- Admin authorization is database-backed (never trust a client-supplied role).
create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.role = 'admin' and coalesce(p.is_suspended,false)=false
  );
$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Admin-only audit log writes should be performed through trusted server routes.
alter table public.admin_audit_logs enable row level security;
drop policy if exists audit_admin_read on public.admin_audit_logs;
create policy audit_admin_read on public.admin_audit_logs
for select to authenticated using (public.is_admin());

-- Storage bucket setup (create bucket 'ad-images' in Supabase Storage, private).
-- These policies allow owners to upload into their own UUID folder.
-- Public image access should be via approved-ad server/public signed URLs or a public bucket
-- only after moderation; private bucket is safer as a default.
drop policy if exists "ad_images_owner_insert" on storage.objects;
create policy "ad_images_owner_insert" on storage.objects
for insert to authenticated
with check (
  bucket_id = 'ad-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "ad_images_owner_delete" on storage.objects;
create policy "ad_images_owner_delete" on storage.objects
for delete to authenticated
using (
  bucket_id = 'ad-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "ad_images_owner_update" on storage.objects;
create policy "ad_images_owner_update" on storage.objects
for update to authenticated
using (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text)
with check (bucket_id='ad-images' and (storage.foldername(name))[1]=auth.uid()::text);

-- Do not expose storage objects indiscriminately. Public reads must be mediated by
-- approved-ad checks / signed URLs in a server route.


-- ===== phase3-expiry.sql =====
-- 48-hour approved advertisement expiration.
-- Adapt column names if Phase 2 schema differs. This SQL assumes:
-- ads(id, status, approved_at, expires_at, deleted_at)
-- ad_images(id, ad_id, storage_path)
-- published_ads_counter(singleton_id, total_published)
-- Use Supabase Storage deletion API from a server/Edge Function; SQL cannot safely
-- delete Storage files by itself.

alter table public.ads add column if not exists approved_at timestamptz;
alter table public.ads add column if not exists expires_at timestamptz;
alter table public.ads add column if not exists expired_at timestamptz;

create or replace function public.set_ad_48h_expiry()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.status = 'approved' and (old.status is distinct from 'approved') then
    if new.approved_at is null then new.approved_at := now(); end if;
    new.expires_at := new.approved_at + interval '48 hours';
  end if;
  return new;
end;
$$;

drop trigger if exists trg_ad_48h_expiry on public.ads;
create trigger trg_ad_48h_expiry
before update of status on public.ads
for each row execute function public.set_ad_48h_expiry();

-- Idempotent expiry marker. The actual data + Storage removal is performed by
-- the secure scheduled worker (docs/48-hour-cleanup.md).
create index if not exists ads_due_expiry_idx
on public.ads (expires_at) where status='approved' and expired_at is null;
