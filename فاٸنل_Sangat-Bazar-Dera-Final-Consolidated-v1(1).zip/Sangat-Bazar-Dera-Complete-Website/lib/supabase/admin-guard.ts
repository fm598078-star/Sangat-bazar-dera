import 'server-only';
import { redirect } from 'next/navigation';
import { createClient } from './server';

/** Call in every admin server page/route. Never rely on client-side hiding. */
export async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) redirect('/login');
  const { data: profile, error: profileError } = await supabase
    .from('profiles').select('role,is_suspended').eq('id', user.id).single();
  if (profileError || profile?.role !== 'admin' || profile?.is_suspended) redirect('/admin/denied');
  return { supabase, user, profile };
}
