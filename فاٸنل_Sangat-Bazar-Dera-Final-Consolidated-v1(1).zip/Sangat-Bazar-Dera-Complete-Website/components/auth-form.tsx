"use client";
import { useState } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
type Mode="signup"|"login"|"forgot"|"reset";
export default function AuthForm({mode}:{mode:Mode}){
 const [name,setName]=useState(""),[phone,setPhone]=useState(""),[email,setEmail]=useState(""),[password,setPassword]=useState(""),[confirm,setConfirm]=useState(""),[message,setMessage]=useState(""),[busy,setBusy]=useState(false);
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage("");const supabase=createClient();
 try{
  if(mode==="signup"){
   if(password.length<8){setMessage("پاس ورڈ کم از کم 8 حروف کا ہونا چاہیے۔");return}
   if(password!==confirm){setMessage("دونوں پاس ورڈ ایک جیسے نہیں۔");return}
   const {error}=await supabase.auth.signUp({email,password,options:{emailRedirectTo:`${location.origin}/auth/callback`,data:{full_name:name,phone}}});
   setMessage(error?error.message:"اکاؤنٹ بن گیا! ای میل میں تصدیقی لنک کھول کر رجسٹریشن مکمل کریں۔");
  }else if(mode==="login"){
   const {error}=await supabase.auth.signInWithPassword({email,password});
   if(error)setMessage(error.message);else location.href="/account";
  }else if(mode==="forgot"){
   const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:`${location.origin}/auth/callback?next=/reset-password`});
   setMessage(error?error.message:"پاس ورڈ تبدیل کرنے کا لنک آپ کی ای میل پر بھیج دیا گیا ہے۔");
  }else{
   if(password.length<8||password!==confirm){setMessage("پاس ورڈ کم از کم 8 حروف اور دونوں خانوں میں یکساں ہونا چاہیے۔");return}
   const {error}=await supabase.auth.updateUser({password});
   setMessage(error?error.message:"پاس ورڈ تبدیل ہو گیا۔ اب لاگ اِن کریں۔");
  }
 }catch{setMessage("عمل مکمل نہ ہو سکا۔ انٹرنیٹ اور Supabase سیٹنگ چیک کریں۔")}finally{setBusy(false)}
 }
 const title={signup:"نیا اکاؤنٹ بنائیں",login:"لاگ اِن",forgot:"پاس ورڈ بھول گئے؟",reset:"نیا پاس ورڈ مقرر کریں"}[mode];
 return <main dir="rtl" style={{maxWidth:480,margin:"40px auto",padding:24,fontFamily:"Arial",background:"#fff",border:"1px solid #e5e7eb",borderRadius:18}}>
 <Link href="/" style={{color:"#155e45"}}>← سنگت بازار ڈیرہ</Link><h1 style={{fontSize:28,color:"#155e45"}}>{title}</h1>
 <form onSubmit={submit} style={{display:"grid",gap:13}}>
 {mode==="signup"&&<><label>پورا نام<input required value={name} onChange={e=>setName(e.target.value)} style={field}/></label><label>موبائل نمبر (اختیاری)<input value={phone} onChange={e=>setPhone(e.target.value)} style={field}/></label></>}
 <label>ای میل<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} style={field}/></label>
 {mode!=="forgot"&&<label>پاس ورڈ<input required type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} style={field}/></label>}
 {(mode==="signup"||mode==="reset")&&<label>پاس ورڈ دوبارہ<input required type="password" minLength={8} value={confirm} onChange={e=>setConfirm(e.target.value)} style={field}/></label>}
 <button disabled={busy} style={{background:"#155e45",color:"white",padding:13,border:0,borderRadius:10,fontWeight:700}}>{busy?"براہِ کرم انتظار کریں…":mode==="signup"?"رجسٹر کریں":mode==="login"?"لاگ اِن":"لنک/پاس ورڈ بھیجیں"}</button>
 </form>{message&&<p role="status" style={{background:"#f0fdf4",padding:12,borderRadius:8}}>{message}</p>}
 <div style={{display:"grid",gap:8,marginTop:16}}>{mode!=="login"&&<Link href="/login">پہلے سے اکاؤنٹ ہے؟ لاگ اِن</Link>}{mode!=="signup"&&<Link href="/signup">نیا اکاؤنٹ بنائیں</Link>}{mode!=="forgot"&&<Link href="/forgot-password">پاس ورڈ بھول گئے؟</Link>}</div></main>
}
const field:React.CSSProperties={display:"block",width:"100%",boxSizing:"border-box",padding:12,marginTop:6,border:"1px solid #cbd5e1",borderRadius:8};
