# Sangat Bazar Dera — Phase 4 v0.4
Phase 2 project base + Phase 3 security/admin scaffolding + Phase 4 Auth flows.

See `docs/PHASE4-URDU.md` for Urdu setup. Development foundation; test in staging before public production.
